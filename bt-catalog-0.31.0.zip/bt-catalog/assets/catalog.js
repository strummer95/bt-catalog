/* BT Catalog storefront — data-driven from the REST API.
   Builds the whole UI inside #btcat-root; styled by catalog.css (the approved mock styles). */
(function () {
  var CFG = window.btcatCfg || { rest: '/wp-json/boomerts/v1/' };
  var REST = CFG.rest.replace(/\/?$/, '/');
  var SIZES_ORDER = ['XS','S','M','L','XL','2XL','3XL','4XL','5XL'];
  var FAMILIES = [['Black','#1d1d1d'],['White','#ffffff'],['Grey','#9aa0a8'],['Blue','#2049b8'],
    ['Red','#b3132a'],['Green','#1f7a44'],['Yellow','#e8a417'],['Orange','#e8601c'],
    ['Pink','#e535ab'],['Purple','#5b2a86'],['Neutral','#d8c6a0']];

  var F = { s:'', brand:'', category:'', fit:'', neck:'', sleeve:'', closure:'', material:'', size:'', color:'', quality:'', pmin:'', pmax:'', sort:'', page:1 };
  var priceBounds = { min:0, max:0 };   // the track's ends, from the facets
  var current = null, currentColor = null, curPid = null;

  /* ---------- shareable URL state ---------- */
  // NOTE: 'q' and 'pg' on purpose — 's' and 'page' are WordPress-reserved
  // query vars, and a full page load of /catalog/?s=... makes WP run a site
  // search instead of rendering the catalog page (hello 404 on browser Back).
  function syncURL(push){
    var q = [];
    if (F.s)        q.push('q=' + encodeURIComponent(F.s));
    if (F.brand)    q.push('brand=' + encodeURIComponent(F.brand));
    if (F.category) q.push('category=' + encodeURIComponent(F.category));
    if (F.fit)      q.push('fit=' + encodeURIComponent(F.fit));
    if (F.neck)     q.push('neck=' + encodeURIComponent(F.neck));
    if (F.sleeve)   q.push('sleeve=' + encodeURIComponent(F.sleeve));
    if (F.closure)  q.push('closure=' + encodeURIComponent(F.closure));
    if (F.material) q.push('material=' + encodeURIComponent(F.material));
    if (F.size)     q.push('size=' + encodeURIComponent(F.size));
    if (F.color)    q.push('color=' + encodeURIComponent(F.color));
    if (F.quality)  q.push('quality=' + encodeURIComponent(F.quality));
    if (F.pmin !== '') q.push('pmin=' + encodeURIComponent(F.pmin));
    if (F.pmax !== '') q.push('pmax=' + encodeURIComponent(F.pmax));
    if (F.sort)     q.push('sort=' + encodeURIComponent(F.sort));
    if (F.page > 1) q.push('pg=' + F.page);
    if (curPid)     q.push('pid=' + encodeURIComponent(curPid));
    var url = location.pathname + (q.length ? ('?' + q.join('&')) : '');
    try { if (push) history.pushState(null, '', url); else history.replaceState(null, '', url); } catch(e){}
  }
  function readURL(){
    var p;
    try { p = new URLSearchParams(location.search); } catch(e){ return null; }
    F.s        = p.get('q') || '';
    F.brand    = p.get('brand') || '';
    F.category = p.get('category') || '';
    F.fit      = p.get('fit') || '';
    F.neck     = p.get('neck') || '';
    F.sleeve   = p.get('sleeve') || '';
    F.closure  = p.get('closure') || '';
    F.material = p.get('material') || '';
    F.size     = p.get('size') || '';
    F.color    = p.get('color') || '';
    F.quality  = p.get('quality') || '';
    F.pmin     = p.get('pmin') || '';
    F.pmax     = p.get('pmax') || '';
    F.sort     = p.get('sort') || '';
    F.page     = parseInt(p.get('pg') || '1', 10) || 1;
    return p.get('pid');
  }
  var quote = [], dStep = 1, method = 'print', locs = 1, embType = 'text', sent = false;
  var lastEst = null;
  var contact = { name:'', email:'', phone:'', notes:'' };
  var btScrollMem = 0;

  var root = document.getElementById('btcat-root');
  if (!root) return;

  function esc(s){ return String(s == null ? '' : s).replace(/[&<>"]/g, function(c){
    return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]; }); }
  function money(n){ return '$' + (Math.round(n*100)/100).toFixed(2); }
  // Short supplier tag shown before the style number (internal-friendly hint).
  function supLabel(s){ return s === 'ss' ? 'SS ' : s === 'sanmar' ? 'SM ' : s === 'egpro' ? 'EG ' : ''; }
  function api(path){ return fetch(REST + path, { credentials:'same-origin' }).then(function(r){ return r.json(); }); }

  /* ---------- shell ---------- */
  root.innerHTML =
    '<section class="hero"><div class="wrap herorow">' +
      '<h1>Browse Products. Get a <span>Quote.</span></h1>' +
      '<div class="csearch">\uD83D\uDD0D<input id="btSearch" placeholder="Search style # or product\u2026"></div>' +
      '<button id="btFab" class="btcat-fab">My Quote \u00b7 <span id="btBadge">0</span></button>' +
    '</div></section>' +
    '<div class="wrap"><div class="catnav">' +
      '<nav class="cmenus">' +
        '<div class="cm"><span class="cmlabel">Brands <span class="cmcaret">\u25be</span></span><div class="cmpop mega-pop" id="mBrands"></div></div>' +
        '<div class="cm"><span class="cmlabel">Categories <span class="cmcaret">\u25be</span></span><div class="cmpop mega-pop" id="mCats"></div></div>' +
        '<div class="cm"><span class="cmlabel">Gender / Age <span class="cmcaret">\u25be</span></span><div class="cmpop mega-pop" id="mFit"></div></div>' +
        '<div class="cm"><span class="cmlabel">Neckline <span class="cmcaret">\u25be</span></span><div class="cmpop mega-pop" id="mNeck"></div></div>' +
        '<div class="cm"><span class="cmlabel">Sleeve <span class="cmcaret">\u25be</span></span><div class="cmpop mega-pop" id="mSleeve"></div></div>' +
        '<div class="cm"><span class="cmlabel">Style <span class="cmcaret">\u25be</span></span><div class="cmpop mega-pop" id="mClosure"></div></div>' +
        '<div class="cm"><span class="cmlabel">Material <span class="cmcaret">\u25be</span></span><div class="cmpop mega-pop" id="mMaterial"></div></div>' +
        '<div class="cm"><span class="cmlabel">Size <span class="cmcaret">\u25be</span></span><div class="cmpop mega-pop" id="mSize"></div></div>' +
        '<div class="cm"><span class="cmlabel">Colors <span class="cmcaret">\u25be</span></span><div class="cmpop mega-pop" id="mColors"></div></div>' +
        '<div class="cm"><span class="cmlabel">Quality <span class="cmcaret">\u25be</span></span><div class="cmpop mega-pop" id="mQuality"></div></div>' +
        '<div class="cm"><span class="cmlabel">Price <span class="cmcaret">\u25be</span></span><div class="cmpop mega-pop" id="mPrice"></div></div>' +
      '</nav>' +
    '</div></div>' +
    '<div class="wrap shell">' +
      '<aside class="btside" id="btSide">' +
        '<div class="fsec collapsed"><div class="fhead">Categories</div><div class="fbody" id="fCats"></div></div>' +
        '<div class="fsec collapsed"><div class="fhead">Gender / Age</div><div class="fbody" id="fFit"></div></div>' +
        '<div class="fsec collapsed"><div class="fhead">Neckline</div><div class="fbody" id="fNeck"></div></div>' +
        '<div class="fsec collapsed"><div class="fhead">Sleeve Length</div><div class="fbody" id="fSleeve"></div></div>' +
        '<div class="fsec collapsed"><div class="fhead">Style</div><div class="fbody" id="fClosure"></div></div>' +
        '<div class="fsec collapsed"><div class="fhead">Material</div><div class="fbody" id="fMaterial"></div></div>' +
        '<div class="fsec collapsed"><div class="fhead">Size</div><div class="fbody fsizes" id="fSize"></div></div>' +
        '<div class="fsec collapsed"><div class="fhead">Colors</div><div class="fbody fcolors" id="fColors"></div></div>' +
        '<div class="fsec collapsed"><div class="fhead">Brands</div><div class="fbody fscroll" id="fBrands"></div></div>' +
        '<div class="fsec collapsed"><div class="fhead">Price</div><div class="fbody" id="fPrice"></div></div>' +
        '<div class="fsec collapsed"><div class="fhead">Quality</div><div class="fbody" id="fQuality"></div></div>' +
      '</aside>' +
      '<main>' +
      '<div class="toolbar"><div class="count"><b id="btCount">0</b> styles</div><div class="tbright"><div id="btActive"></div>' +
        '<select id="btSort" class="sort">' +
          '<option value="">Sort: Featured</option>' +
          '<option value="price_asc">Price: Low to High</option>' +
          '<option value="price_desc">Price: High to Low</option>' +
          '<option value="name_asc">Name: A to Z</option>' +
          '<option value="brand_asc">Brand: A to Z</option>' +
        '</select></div></div>' +
      '<div class="grid" id="btGrid"></div>' +
      '<div class="pager" id="btPager"></div>' +
    '</main></div>' +
    '<div id="btPdp" class="pdp" style="display:none"></div>' +
    '<div id="btDrawer" class="drawer" style="display:none"></div>' +
    '<div id="btScrim" class="scrim" style="display:none;position:fixed;inset:0;z-index:75;background:rgba(0,0,0,.45)"></div>';

  // Quote button styling (inline, above the search bar)
  var fab = document.getElementById('btFab');
  fab.style.cssText = 'background:#e535ab;color:#fff;border:0;' +
    'font-family:Oswald,sans-serif;text-transform:uppercase;letter-spacing:.5px;font-size:14px;padding:9px 18px;' +
    'border-radius:8px;box-shadow:0 2px 8px rgba(229,53,171,.3);cursor:pointer';
  fab.addEventListener('click', openDrawer);

  /* ---------- menus ---------- */
  function bindMenus(){
    var labels = root.querySelectorAll('.cmlabel');
    labels.forEach(function(l){ l.addEventListener('click', function(e){ e.stopPropagation(); toggleMenu(l.parentNode); }); });
    document.addEventListener('click', function(e){ if(!e.target.closest('.cm')) closeMenus(); });
    root.querySelectorAll('.fsec .fhead').forEach(function(h){ h.addEventListener('click', function(){ h.parentNode.classList.toggle('collapsed'); }); });
  }
  function toggleMenu(cm){ var o = cm.classList.contains('open'); closeMenus(); if(!o) cm.classList.add('open'); }
  function closeMenus(){ root.querySelectorAll('.cm.open').forEach(function(e){ e.classList.remove('open'); }); }

  /* ---------- facets ----------
     One config drives both the header dropdowns and the sidebar rail, so a
     filter can never exist in one place and not the other. The server returns
     [{k,v,n}] per group with every zero-count value already dropped; we render
     what's left and hide any group that has nothing useful to offer. */
  var GROUPS = [
    { key:'category', src:'categories', menu:'mCats',    side:'fCats'    },
    { key:'fit',      src:'fits',       menu:'mFit',     side:'fFit'     },
    { key:'neck',     src:'necks',      menu:'mNeck',    side:'fNeck'    },
    { key:'sleeve',   src:'sleeves',    menu:'mSleeve',  side:'fSleeve'  },
    { key:'closure',  src:'closures',   menu:'mClosure', side:'fClosure' },
    { key:'material', src:'materials',  menu:'mMaterial', side:'fMaterial' },
    { key:'size',     src:'sizes',      menu:'mSize',    side:'fSize'    },
    { key:'color',    src:'colors',     menu:'mColors',  side:'fColors', swatch:true },
    { key:'brand',    src:'brands',     menu:'mBrands',  side:'fBrands', cols:true   },
    { key:'quality',  src:'qualities',  menu:'mQuality', side:'fQuality' }
  ];
  var FAMHEX = {};
  FAMILIES.forEach(function(f){ FAMHEX[f[0]] = f[1]; });
  var LBL = {};          // key -> { value : display label } for chips
  var facetSeq = 0;      // drops out-of-order facet responses

  function famDot(v){
    var hex = FAMHEX[v] || '#ccc';
    return '<span class="cdot" style="background:' + hex + '"></span>';
  }
  function countTag(n){ return '<i class="fn">' + n + '</i>'; }

  // Which section (.cm or .fsec) an element lives in, so we can hide it whole.
  function hostOf(el, sel){ return el ? el.closest(sel) : null; }

  function renderGroup(g, items){
    var el, i;
    LBL[g.key] = {};
    for (i = 0; i < items.length; i++) LBL[g.key][items[i].k] = items[i].v;

    // Every group stays on screen so the filter bar and rail don't vanish
    // under a narrow search (one result left every group with < 2 options
    // and hid them all). A group with nothing for these results is dimmed.
    var none = items.length === 0;

    var menuHtml, sideHtml;
    if (g.cols) {
      var ncol = window.innerWidth < 600 ? 2 : (window.innerWidth < 900 ? 3 : 5);
      var per = Math.ceil(items.length / ncol) || 1, out = '';
      for (var ci = 0; ci < ncol; ci++) {
        var slice = items.slice(ci * per, (ci + 1) * per);
        if (!slice.length) continue;
        out += '<div class="brandcol">' + slice.map(function(x){
          return '<div class="megai" data-f="' + g.key + '" data-v="' + esc(x.k) + '">' + esc(x.v) + countTag(x.n) + '</div>';
        }).join('') + '</div>';
      }
      menuHtml = '<div class="mega megabrands">' + out + '</div>';
    } else {
      menuHtml = '<div class="mega"><div class="megacol">' + items.map(function(x){
        return '<div class="megai' + (g.swatch ? ' colori' : '') + '" data-f="' + g.key + '" data-v="' + esc(x.k) + '">' +
               (g.swatch ? famDot(x.k) : '') + esc(x.v) + countTag(x.n) + '</div>';
      }).join('') + '</div></div>';
    }
    sideHtml = none ? '<div class="fnone">None in these results</div>' : items.map(function(x){
      return '<div class="fitem' + (g.swatch ? ' fcolor' : '') + '" data-f="' + g.key + '" data-v="' + esc(x.k) + '">' +
             (g.swatch ? famDot(x.k) : '') + esc(x.v) + countTag(x.n) + '</div>';
    }).join('');

    el = document.getElementById(g.menu);
    if (el) { el.innerHTML = menuHtml; var cm = hostOf(el, '.cm'); if (cm) { cm.style.display = ''; cm.classList.toggle('dim', none); } }
    el = document.getElementById(g.side);
    if (el) { el.innerHTML = sideHtml; var fs = hostOf(el, '.fsec'); if (fs) { fs.style.display = ''; fs.classList.toggle('dim', none); } }
  }

  /* ---------- price range ----------
     Not a GROUPS entry: every other filter is one value chosen from a list of
     chips, this one is two numbers over a continuous range, so it has its own
     markup and its own render. Two overlaid range inputs give the familiar
     two-handle slider while staying real <input> elements, so it is keyboard
     operable and screen readers announce it. The boxes underneath take an
     exact figure, because a slider cannot hit $18.95 reliably. */
  function priceLo(){ return F.pmin !== '' ? Math.max(priceBounds.min, parseFloat(F.pmin)) : priceBounds.min; }
  function priceHi(){ return F.pmax !== '' ? Math.min(priceBounds.max, parseFloat(F.pmax)) : priceBounds.max; }

  function priceHtml(idp){
    var lo = priceLo(), hi = priceHi(), mn = priceBounds.min, mx = priceBounds.max;
    var span = (mx - mn) || 1;
    var lpc = ((lo - mn) / span) * 100, hpc = ((hi - mn) / span) * 100;
    return '' +
      '<div class="prng">' +
        '<div class="prngout">' + money(lo) + ' \u2013 ' + money(hi) + (hi >= mx ? '+' : '') + '</div>' +
        '<div class="prngtrack">' +
          '<div class="prngfill" style="left:' + lpc + '%;right:' + (100 - hpc) + '%"></div>' +
          '<input type="range" class="prngin prnglo" id="' + idp + 'Lo" aria-label="Minimum price" min="' + mn + '" max="' + mx + '" step="1" value="' + lo + '">' +
          '<input type="range" class="prngin prnghi" id="' + idp + 'Hi" aria-label="Maximum price" min="' + mn + '" max="' + mx + '" step="1" value="' + hi + '">' +
        '</div>' +
        '<div class="prngbox">' +
          '<label class="prnglbl">Min <input type="number" class="prngnum" id="' + idp + 'NumLo" inputmode="decimal" min="' + mn + '" max="' + mx + '" step="0.01" value="' + lo.toFixed(2) + '"></label>' +
          '<label class="prnglbl">Max <input type="number" class="prngnum" id="' + idp + 'NumHi" inputmode="decimal" min="' + mn + '" max="' + mx + '" step="0.01" value="' + hi.toFixed(2) + '"></label>' +
          '<button type="button" class="prngclr" id="' + idp + 'Clr">Reset</button>' +
        '</div>' +
      '</div>';
  }

  // Commit on change/blur, never on input: every commit refetches the grid and
  // the facets, and firing that per pixel of drag would hammer the server.
  function bindPrice(idp){
    var lo  = document.getElementById(idp + 'Lo');
    var hi  = document.getElementById(idp + 'Hi');
    var nlo = document.getElementById(idp + 'NumLo');
    var nhi = document.getElementById(idp + 'NumHi');
    var clr = document.getElementById(idp + 'Clr');
    if (!lo || !hi) return;

    function commit(a, b){
      var mn = priceBounds.min, mx = priceBounds.max;
      a = isFinite(a) ? Math.min(Math.max(a, mn), mx) : mn;
      b = isFinite(b) ? Math.min(Math.max(b, mn), mx) : mx;
      if (a > b) { var t = a; a = b; b = t; }
      // At the ends it is not a filter: leave it out so the URL stays clean
      // and bt_cat_params_empty() still sees an unfiltered catalog.
      F.pmin = (a <= mn) ? '' : String(a);
      F.pmax = (b >= mx) ? '' : String(b);
      F.page = 1;
      closeMenus(); renderActive(); syncURL(); loadGrid(); loadFacets();
    }
    // While dragging, move only the readout and the fill - no requests.
    function preview(){
      var a = parseFloat(lo.value), b = parseFloat(hi.value);
      if (a > b) { var t = a; a = b; b = t; }
      var mn = priceBounds.min, mx = priceBounds.max, span = (mx - mn) || 1;
      var out = lo.parentNode.parentNode.querySelector('.prngout');
      var fil = lo.parentNode.querySelector('.prngfill');
      if (out) out.textContent = money(a) + '\u2013' + money(b) + (b >= mx ? '+' : '');
      if (fil) { fil.style.left = (((a - mn) / span) * 100) + '%'; fil.style.right = (100 - ((b - mn) / span) * 100) + '%'; }
      if (nlo) nlo.value = a.toFixed(2);
      if (nhi) nhi.value = b.toFixed(2);
    }
    lo.addEventListener('input', preview);
    hi.addEventListener('input', preview);
    lo.addEventListener('change', function(){ commit(parseFloat(lo.value), parseFloat(hi.value)); });
    hi.addEventListener('change', function(){ commit(parseFloat(lo.value), parseFloat(hi.value)); });
    function numCommit(){ commit(parseFloat(nlo.value), parseFloat(nhi.value)); }
    if (nlo) { nlo.addEventListener('change', numCommit);
               nlo.addEventListener('keydown', function(e){ if (e.key === 'Enter') { e.preventDefault(); numCommit(); } }); }
    if (nhi) { nhi.addEventListener('change', numCommit);
               nhi.addEventListener('keydown', function(e){ if (e.key === 'Enter') { e.preventDefault(); numCommit(); } }); }
    if (clr) clr.addEventListener('click', function(){
      F.pmin = ''; F.pmax = ''; F.page = 1;
      closeMenus(); renderActive(); syncURL(); loadGrid(); loadFacets();
    });
  }

  function renderPrice(b){
    if (b && typeof b.min === 'number' && typeof b.max === 'number' && b.max > b.min) {
      priceBounds = { min: b.min, max: b.max };
    }
    var none = !(priceBounds.max > priceBounds.min);
    [['mPrice','pm'], ['fPrice','pf']].forEach(function(pair){
      var el = document.getElementById(pair[0]);
      if (!el) return;
      el.innerHTML = none ? '<div class="fnone">None in these results</div>' : priceHtml(pair[1]);
      var host = hostOf(el, pair[0] === 'mPrice' ? '.cm' : '.fsec');
      if (host) { host.style.display = ''; host.classList.toggle('dim', none); }
      if (!none) bindPrice(pair[1]);
    });
  }

  // Facets are recomputed against the ACTIVE filters, which is what makes
  // impossible combinations disappear instead of returning "No styles match".
  function loadFacets(){
    var seq = ++facetSeq;
    api('catalog/facets' + qs()).then(function(f){
      if (seq !== facetSeq) return;              // a newer request already answered
      f = f || {};
      GROUPS.forEach(function(g){ renderGroup(g, (f[g.src] || [])); });
      renderPrice(f.price);
      renderActive();                            // chips pick up real labels
      markActive();
    });
  }

  /* ---------- filter state ---------- */
  // Shared query string for both the list and the facet counts — one builder,
  // so counts can never be computed against a different filter set than results.
  function qs(extra){
    var q = [];
    if (F.s)        q.push('s=' + encodeURIComponent(F.s));
    if (F.brand)    q.push('brand=' + encodeURIComponent(F.brand));
    if (F.category) q.push('category=' + encodeURIComponent(F.category));
    if (F.fit)      q.push('fit=' + encodeURIComponent(F.fit));
    if (F.neck)     q.push('neck=' + encodeURIComponent(F.neck));
    if (F.sleeve)   q.push('sleeve=' + encodeURIComponent(F.sleeve));
    if (F.closure)  q.push('closure=' + encodeURIComponent(F.closure));
    if (F.material) q.push('material=' + encodeURIComponent(F.material));
    if (F.size)     q.push('size=' + encodeURIComponent(F.size));
    if (F.color)    q.push('color=' + encodeURIComponent(F.color));
    if (F.quality)  q.push('quality=' + encodeURIComponent(F.quality));
    if (F.pmin !== '') q.push('pmin=' + encodeURIComponent(F.pmin));
    if (F.pmax !== '') q.push('pmax=' + encodeURIComponent(F.pmax));
    if (extra) q = q.concat(extra);
    return q.length ? ('?' + q.join('&')) : '';
  }
  function anyFilter(){
    return !!(F.s || F.brand || F.category || F.fit || F.neck || F.sleeve ||
              F.closure || F.material || F.size || F.color || F.quality || F.sort ||
              F.pmin !== '' || F.pmax !== '');
  }

  function setFilter(key, val){
    F[key] = (F[key] === val) ? '' : val;  // toggle
    F.page = 1; closeMenus(); renderActive(); syncURL(); loadGrid(); loadFacets();
  }
  function clearFilter(key){
    if (key === 'price') { F.pmin = ''; F.pmax = ''; }
    else F[key] = '';
    F.page = 1; renderActive(); syncURL(); loadGrid(); loadFacets();
  }
  function chipLabel(key, val){
    return (LBL[key] && LBL[key][val]) ? LBL[key][val] : val;
  }
  function renderActive(){
    var bits = [];
    GROUPS.forEach(function(g){
      if (!F[g.key]) return;
      bits.push('<span class="chip" data-clear="' + g.key + '">' + esc(chipLabel(g.key, F[g.key])) + ' \u00d7</span>');
    });
    if (F.pmin !== '' || F.pmax !== '') {
      var plo = F.pmin !== '' ? money(parseFloat(F.pmin)) : money(priceBounds.min);
      var phi = F.pmax !== '' ? money(parseFloat(F.pmax)) : money(priceBounds.max) + '+';
      bits.push('<span class="chip" data-clear="price">' + plo + ' \u2013 ' + phi + ' \u00d7</span>');
    }
    var el = document.getElementById('btActive');
    el.innerHTML = bits.join('');
    el.querySelectorAll('[data-clear]').forEach(function(c){
      c.addEventListener('click', function(){ clearFilter(c.getAttribute('data-clear')); });
    });
    markActive();
  }
  function markActive(){
    function on(el){
      var k = el.getAttribute('data-f');
      return !!(k && F[k] && F[k] === el.getAttribute('data-v'));
    }
    root.querySelectorAll('.fitem').forEach(function(el){ el.classList.toggle('active', on(el)); });
    root.querySelectorAll('.megai').forEach(function(el){ el.classList.toggle('on', on(el)); });
  }

  // One delegated handler covers every filter option in both the dropdowns and
  // the sidebar, including the ones re-rendered after each facet refresh.
  root.addEventListener('click', function(e){
    var el = e.target.closest('[data-f][data-v]');
    if (!el || !root.contains(el)) return;
    setFilter(el.getAttribute('data-f'), el.getAttribute('data-v'));
  });

  /* ---------- grid ---------- */
  function loadGrid(){
    var extra = ['page=' + F.page, 'per=24'];
    if (F.sort) extra.push('sort=' + encodeURIComponent(F.sort));
    if (!anyFilter()) extra.push('featured=1');
    var q = 'catalog' + qs(extra);
    var grid = document.getElementById('btGrid');
    grid.innerHTML = '<div style="grid-column:1/-1;padding:40px;text-align:center;color:#8a8aa0">Loading\u2026</div>';
    api(q).then(function(d){
      document.getElementById('btCount').textContent = d.total || 0;
      var cwrap = document.getElementById('btCount').parentNode;
      if (cwrap) cwrap.lastChild.textContent = d.featured ? ' featured styles' : ' styles';
      if (!d.items || !d.items.length){ grid.innerHTML = '<div class="noresults" style="grid-column:1/-1;text-align:center;padding:50px;color:#8a8aa0">No styles match.</div>'; document.getElementById('btPager').innerHTML=''; return; }
      grid.innerHTML = d.items.map(function(p){
        var img = p.thumb ? '<img src="'+esc(p.thumb)+'" loading="lazy" onerror="this.style.display=\'none\'">'
                          : '<div style="display:flex;align-items:center;justify-content:center;height:100%;color:#ccc;font-size:13px">No image</div>';
        var onSale = !!(p.sale || p.was);
        var priceHtml;
        if (p.pmin != null && p.pmax != null && p.pmax > p.pmin) {
          // Colorways price differently (specials or white-vs-colors pricing):
          // show the range; red + Sale badge when any colorway is on special.
          priceHtml = '<div class="price'+(onSale?' onsale':'')+'">'+money(p.pmin)+'\u2013'+money(p.pmax)+' <small>/ea</small></div>';
        } else if (p.was) {
          priceHtml = '<div class="price onsale">'+money(p.price)+' <small>/ea</small> <s class="was">'+money(p.was)+'</s></div>';
        } else {
          priceHtml = '<div class="price">'+money((p.pmin != null ? p.pmin : p.price))+' <small>/ea</small></div>';
        }
        return '<div class="pcard" data-id="'+p.id+'">' +
          '<div class="pimg">'+(p.popular ? '<span class="poptag">Popular</span>' : '')+(onSale ? '<span class="saletag">Sale</span>' : '')+img+'</div>' +
          '<div class="pbody"><div class="pbrand">'+esc(p.brand)+'</div><div class="pname">'+esc(p.name||p.style)+'</div>' +
          '<div class="pstyle">'+supLabel(p.supplier)+'Style '+esc(p.style)+'</div>' +
          '<div class="row">'+priceHtml+
          '<div class="colorcount">'+p.colors+' colors available</div></div></div></div>';
      }).join('');
      grid.querySelectorAll('.pcard').forEach(function(){});
      renderPager(d.page, d.pages);
    });
  }
  function renderPager(page, pages){
    var el = document.getElementById('btPager');
    if (pages <= 1){ el.innerHTML=''; return; }
    el.innerHTML = '<button class="pgbtn" '+(page<=1?'disabled':'')+' data-go="'+(page-1)+'">\u2039 Prev</button>' +
      '<span class="pginfo">Page '+page+' of '+pages+'</span>' +
      '<button class="pgbtn" '+(page>=pages?'disabled':'')+' data-go="'+(page+1)+'">Next \u203a</button>';
    el.querySelectorAll('[data-go]').forEach(function(b){ b.addEventListener('click', function(){ if(b.disabled) return; F.page=parseInt(b.getAttribute('data-go'),10); syncURL(); loadGrid(); window.scrollTo({top:root.offsetTop,behavior:'smooth'}); }); });
  }

  /* ---------- preferred default colorway (navy-first), mirrors rest.php ---------- */
  function hexRgb(hex){ var h=String(hex||'').replace('#',''); if(h.length===3){h=h[0]+h[0]+h[1]+h[1]+h[2]+h[2];} if(!/^[0-9a-fA-F]{6}$/.test(h)) return null; return [parseInt(h.substr(0,2),16),parseInt(h.substr(2,2),16),parseInt(h.substr(4,2),16)]; }
  function colorRank(name, hex){
    var n=String(name||'').trim().toLowerCase();
    if (n==='navy') return 0;
    if (n.indexOf('navy')!==-1) return 1;
    var rgb=hexRgb(hex), lum=rgb?((rgb[0]+rgb[1]+rgb[2])/3):null;
    if ((rgb && lum<120 && (n.indexOf('blue')!==-1 || (rgb[2]>rgb[0]+15 && rgb[2]>rgb[1]+15))) || /midnight|indigo|royal|cobalt|marine/.test(n)) return 2;
    if (/gray|grey|charcoal|graphite|slate|oxford/.test(n)) return 3;
    if (rgb){ var mx=Math.max.apply(null,rgb), mn=Math.min.apply(null,rgb); if ((mx-mn)<=30 && lum>=50 && lum<=215) return 3; }
    return 99;
  }
  function preferredColorIdx(colors){
    var best=-1, br=999;
    for (var i=0;i<colors.length;i++){ if(!colors[i] || !colors[i].img) continue; var r=colorRank(colors[i].name, colors[i].hex); if(r<br){br=r;best=i;} }
    if (best>=0) return best;
    for (var j=0;j<colors.length;j++){ if(colors[j] && colors[j].img) return j; }
    return 0;
  }

  /* ---------- product detail ---------- */
  function openPDP(id, fromPop){
    api('catalog/item?id=' + id).then(function(p){
      if (!p || p.error){ console.error('BT Catalog: item load failed for id ' + id, p); alert('Sorry — could not load that product. Please try again.'); return; }
      var colors = Array.isArray(p.colors) ? p.colors : [];
      var specs  = Array.isArray(p.specs)  ? p.specs  : [];
      var sizes  = (Array.isArray(p.sizes) && p.sizes.length) ? p.sizes : ['S','M','L','XL','2XL'];
      current = p; current.colors = colors; current.sizes = sizes;
      currentColor = (colors[preferredColorIdx(colors)] || {}).name || (colors[0] && colors[0].name) || null;

      var pdp = document.getElementById('btPdp');
      pdp.innerHTML =
        '<div class="wrap"><span class="back">\u2190 Back to catalog</span>' +
        '<div class="pdp-grid"><div class="pdp-img" id="btPdpImg"></div><div>' +
          '<div class="pbrand">'+esc(p.brand)+'</div><h1>'+esc(p.name||p.style)+'</h1>' +
          '<div class="pstyle">'+supLabel(p.supplier)+'Style '+esc(p.style)+'</div>' +
          '<div class="price" id="btPdpPrice"></div>' +
          '<div class="priceNote">Per-piece retail before decoration. Final price comes back on your quote.</div>' +
          '<div class="desc">'+(p.desc||'')+'</div>' +
          '<ul class="specs">'+ specs.map(function(s){ return '<li><span>'+esc(s[0])+'</span><span>'+esc(s[1])+'</span></li>'; }).join('') +'</ul>' +
          '<div class="lab">Sizes &amp; quantity</div>' +
          '<div class="sizegrid" id="btSizes"></div>' +
          '<button class="addbtn" id="btAdd" style="margin-top:12px">Add to Quote</button>' +
          '<div class="lab">Color <span id="btColorName" style="color:#8a8aa0;text-transform:none;letter-spacing:0"></span></div>' +
          '<div class="colorgrid" id="btColors2"></div>' +
        '</div></div></div>';
      pdp.style.cssText = '';
      pdp.className = 'pdp show';
      root.classList.add('bt-pdp-open');
      btScrollMem = window.scrollY || window.pageYOffset || 0;
      window.scrollTo(0, 0);
      pdp.querySelector('.back').addEventListener('click', closePDP);

      renderColors(current);
      renderSizes(current);
      document.getElementById('btAdd').addEventListener('click', addToQuote);
      var wasOpen = !!curPid;
      curPid = String(id);
      if (fromPop) { syncURL(); }               // history already moved
      else { syncURL(!wasOpen); pdpPushed = !wasOpen || pdpPushed; }
    }).catch(function(err){ console.error('BT Catalog: item fetch error', err); alert('Sorry — could not load that product.'); });
  }
  var pdpPushed = false;
  function closePDP(skipHistory){
    var p=document.getElementById('btPdp'); p.className='pdp'; p.style.cssText='display:none';
    root.classList.remove('bt-pdp-open'); window.scrollTo(0, btScrollMem||0); curPid=null;
    if (!skipHistory){
      if (pdpPushed){ pdpPushed=false; history.back(); return; }   // popstate finishes the URL cleanup
      syncURL();
    }
    pdpPushed = false;
  }
  // Browser Back/Forward: close or open the product view in place instead of
  // doing a full page load (which is what used to 404 on WP's search hijack).
  window.addEventListener('popstate', function(){
    var pid = readURL();
    var si2 = document.getElementById('btSearch'); if (si2) si2.value = F.s;
    var so2 = document.getElementById('btSort');   if (so2) so2.value = F.sort;
    if (!pid && curPid){ closePDP(true); renderActive(); loadGrid(); loadFacets(); return; }
    if (pid && pid !== curPid){ openPDP(pid, true); return; }
    if (!pid){ renderActive(); loadGrid(); loadFacets(); }
  });

  function selColor(){
    return current.colors.filter(function(x){ return x.name===currentColor; })[0] || current.colors[0] || {};
  }
  function colorPrice(c){
    var price = (c && c.price != null) ? c.price : current.price;
    var was   = (c && c.price != null) ? c.was   : current.was;
    return { price: price, was: was || null };
  }
  function updatePdpPrice(){
    var el = document.getElementById('btPdpPrice'); if (!el) return;
    var pr = colorPrice(selColor());
    el.className = pr.was ? 'price onsale' : 'price';
    el.innerHTML = money(pr.price) + ' <small style="font-size:13px;color:#8a8aa0">/ea retail</small>' +
      (pr.was ? ' <s class="was">'+money(pr.was)+'</s> <span class="salepill">Sale</span>' : '');
  }

  function renderColors(p){
    var box = document.getElementById('btColors2');
    box.innerHTML = '<div class="colorprev" id="btColorPrev"></div>' + p.colors.map(function(c){
      var sel = c.name === currentColor ? ' sel' : '';
      var bg = c.swatch
        ? 'background-image:url('+c.swatch+');background-size:cover;background-position:center'
        : ('background:' + (c.hex ? '#' + String(c.hex).replace('#','') : '#dddddd'));
      var saleTag = (c.was != null && c.was > 0) ? '<span class="csale">Sale '+money(c.price)+'</span>' : '';
      return '<div class="copt'+sel+'" data-c="'+esc(c.name)+'"><div class="csq" style="'+bg+'"></div><span class="clabel">'+esc(c.name)+'</span>'+saleTag+'</div>';
    }).join('');
    setColorName();
    box.querySelectorAll('.copt').forEach(function(s){ s.addEventListener('click', function(){
      currentColor = s.getAttribute('data-c');
      box.querySelectorAll('.copt').forEach(function(x){ x.classList.remove('sel'); });
      s.classList.add('sel'); setColorName(); swapImage(); updatePdpPrice();
    }); });
    swapImage(); updatePdpPrice();
  }
  function setColorName(){ var el=document.getElementById('btColorName'); if(el) el.textContent = currentColor ? ('\u2014 '+currentColor) : ''; }
  function swapImage(){
    var c = current.colors.filter(function(x){ return x.name===currentColor; })[0] || current.colors[0];
    var has = c && c.img;
    var img = document.getElementById('btPdpImg');
    if (img) img.innerHTML = has ? '<img src="'+esc(c.img)+'" onerror="this.parentNode.innerHTML=\'<div style=&quot;color:#ccc&quot;>No image</div>\'">'
                                 : '<div style="display:flex;align-items:center;justify-content:center;height:100%;color:#ccc">No image</div>';
    var pv = document.getElementById('btColorPrev');
    if (pv) pv.innerHTML = has ? '<img src="'+esc(c.img)+'">' : '';
  }
  function renderSizes(p){
    var sizes = p.sizes && p.sizes.length ? p.sizes : ['S','M','L','XL','2XL'];
    document.getElementById('btSizes').innerHTML = sizes.map(function(z){
      return '<div class="sizebox"><div class="sz">'+esc(z)+'</div><input type="number" min="0" value="0" data-sz="'+esc(z)+'"></div>';
    }).join('');
  }

  /* Sizes to show/edit/send for a quote line: the product's own size list
     (6XL, youth, talls, OSFA...), not the fixed XS-5XL row, which dropped
     every other size from the drawer and from the quote email. */
  function lineSizes(l){
    var base = (l.sizeList && l.sizeList.length) ? l.sizeList.slice() : SIZES_ORDER.slice();
    Object.keys(l.sizes || {}).forEach(function(z){ if (base.indexOf(z) < 0) base.push(z); });
    return base;
  }

  function addToQuote(){
    var sizes = {}, sizeList = [];
    document.querySelectorAll('#btSizes input').forEach(function(i){ var z=i.getAttribute('data-sz'), v=parseInt(i.value||0,10); sizeList.push(z); if(v>0) sizes[z]=v; });
    var qty = Object.keys(sizes).reduce(function(a,k){ return a+sizes[k]; }, 0);
    if (qty === 0){ alert('Add at least one size quantity.'); return; }
    var c = selColor();
    var pr = colorPrice(c);
    quote.push({ id:current.id, supplier:current.supplier, brand:current.brand, name:current.name||current.style, style:current.style,
      color:currentColor||'', img:c.img||'', price:pr.price, sizes:sizes, sizeList:sizeList, qty:qty });
    updateBadge(); closePDP(); dStep=1; openDrawer();
  }

  /* ---------- quote drawer ---------- */
  function updateBadge(){ var n=quote.reduce(function(a,l){return a+l.qty;},0); document.getElementById('btBadge').textContent=n; }
  function openDrawer(){
    var d = document.getElementById('btDrawer');
    document.getElementById('btScrim').style.display='block';
    d.style.cssText = 'display:flex;flex-direction:column;position:fixed;top:0;right:0;bottom:0;z-index:80;'+
      'width:min(420px,100vw);max-width:100vw;background:#fff;box-shadow:-8px 0 30px rgba(0,0,0,.18);transform:translateX(0)';
    d.classList.add('show');
    document.documentElement.style.overflow='hidden';
    renderDrawer();
  }
  function closeDrawer(){
    document.getElementById('btScrim').style.display='none';
    var d=document.getElementById('btDrawer'); d.classList.remove('show'); d.style.display='none';
    document.documentElement.style.overflow='';
  }
  document.getElementById('btScrim').addEventListener('click', closeDrawer);

  function totalQty(){ return quote.reduce(function(a,l){return a+l.qty;},0); }

  // Live price from the same Quick Quote endpoint the employee portal uses.
  function postPrice(cb){
    var params = 'qty=' + encodeURIComponent(totalQty()) +
                 '&garment=custom&retail=' + encodeURIComponent(quote[0] ? quote[0].price : 0);
    if (method==='emb') params += '&method=embroidery&embType=' + encodeURIComponent(embType);
    else                params += '&method=print&locations=' + encodeURIComponent(locs);
    fetch(REST + 'price', { method:'POST', credentials:'same-origin',
      headers:{'Content-Type':'application/x-www-form-urlencoded'}, body: params })
      .then(function(r){ return r.json(); }).then(cb).catch(function(){ cb(null); });
  }

  function renderDrawer(){
    var d = document.getElementById('btDrawer');
    var head = '<div class="dhead"><div class="dtitle">Your Quote</div><button class="dx" id="btDx">\u2715</button></div>' +
      '<div class="steps">' +
      ['Garment','Decoration','Send'].map(function(lab,i){ var n=i+1; return '<div class="st'+(dStep===n?' on':'')+'" data-step="'+n+'"><b>'+n+'</b>'+lab+'</div>'; }).join('') +
      '</div>';
    var body = '<div class="dbody" id="btDbody" style="flex:1;overflow-y:auto"></div>';
    var foot = '<div class="dfoot" id="btDfoot"></div>';
    d.innerHTML = head + body + foot;
    d.querySelector('#btDx').addEventListener('click', closeDrawer);
    d.querySelectorAll('.steps .st').forEach(function(s){ s.addEventListener('click', function(){ goStep(parseInt(s.getAttribute('data-step'),10)); }); });
    if (dStep===1) stepGarment(); else if (dStep===2) stepDeco(); else stepSend();
  }
  function goStep(n){ if(n>1 && quote.length===0) return; dStep=n; renderDrawer(); }

  function stepGarment(){
    var b = document.getElementById('btDbody');
    if (!quote.length){ b.innerHTML = '<p style="padding:24px;text-align:center;color:#8a8aa0">Your quote is empty. Add a garment from the catalog.</p>'; document.getElementById('btDfoot').innerHTML=''; return; }
    b.innerHTML = quote.map(function(l,idx){
      var inputs = lineSizes(l).map(function(z){
        return '<label class="qsz"><span>'+esc(z)+'</span><input type="number" min="0" value="'+(l.sizes[z]||'')+'" placeholder="0" data-i="'+idx+'" data-z="'+esc(z)+'"></label>';
      }).join('');
      var th = l.img ? '<img src="'+esc(l.img)+'" onerror="this.style.display=\'none\'">' : '';
      return '<div class="qline"><div class="th">'+th+'</div><div class="meta">' +
        '<div class="n">'+esc(l.brand)+' '+esc(l.name)+'</div><div class="s">'+supLabel(l.supplier)+'Style '+esc(l.style)+' \u00b7 '+esc(l.color)+'</div>' +
        '<div class="qsizes">'+inputs+'</div><div class="qsum" id="qsum'+idx+'">'+l.qty+' pcs \u00b7 '+money(l.price)+'/ea</div>' +
        '</div><button class="qrm" data-rm="'+idx+'">\u2715</button></div>';
    }).join('');
    b.querySelectorAll('.qsizes input').forEach(function(i){ i.addEventListener('input', function(){ updateLineSize(+i.getAttribute('data-i'), i.getAttribute('data-z'), i.value); }); });
    b.querySelectorAll('[data-rm]').forEach(function(x){ x.addEventListener('click', function(){ quote.splice(+x.getAttribute('data-rm'),1); updateBadge(); if(!quote.length) dStep=1; renderDrawer(); }); });
    document.getElementById('btDfoot').innerHTML = '<button class="primary" id="btNext">Next: Decoration</button>';
    document.getElementById('btNext').addEventListener('click', function(){ goStep(2); });
  }
  function updateLineSize(idx, z, val){
    val = parseInt(val||0,10);
    if (val>0) quote[idx].sizes[z]=val; else delete quote[idx].sizes[z];
    quote[idx].qty = Object.keys(quote[idx].sizes).reduce(function(a,k){return a+quote[idx].sizes[k];},0);
    updateBadge();
    var s = document.getElementById('qsum'+idx); if(s) s.textContent = quote[idx].qty+' pcs \u00b7 '+money(quote[idx].price)+'/ea';
  }

  function stepDeco(){
    var b = document.getElementById('btDbody');
    var sub = (method==='print')
      ? '<div class="secLab">Print locations</div>' +
        [1,2,3].map(function(n){ var ie=['Front Only','Front &amp; Back','Front, Back &amp; Sleeve'][n-1];
          return '<label class="optcard'+(locs===n?' on':'')+'" data-loc="'+n+'"><span class="oct">'+n+' Location'+(n>1?'s':'')+'</span><span class="ocs">ie: '+ie+'</span><span class="ocb">'+n+' LOC'+(n>1?'S':'')+'</span></label>';
        }).join('')
      : '<div class="secLab">Embroidery type</div>' +
        [['text','Names / Text'],['logo','Logo'],['hard','Hard-to-handle']].map(function(t){
          return '<label class="optcard'+(embType===t[0]?' on':'')+'" data-emb="'+t[0]+'"><span class="oct">'+t[1]+'</span></label>';
        }).join('');
    var qtyBlock = '<div class="secLab">Sizes &amp; quantity</div>' +
      quote.map(function(l,idx){
        var inputs = lineSizes(l).map(function(z){
          return '<label class="qsz"><span>'+esc(z)+'</span><input type="number" min="0" value="'+(l.sizes[z]||'')+'" placeholder="0" data-i="'+idx+'" data-z="'+esc(z)+'"></label>';
        }).join('');
        return '<div class="qline"><div class="meta"><div class="n">'+esc(l.brand)+' '+esc(l.name)+'</div><div class="s">'+supLabel(l.supplier)+'Style '+esc(l.style)+' \u00b7 '+esc(l.color)+'</div><div class="qsizes">'+inputs+'</div><div class="qsum" id="qsum'+idx+'">'+l.qty+' pcs \u00b7 '+money(l.price)+'/ea</div></div></div>';
      }).join('');
    b.innerHTML =
      '<div class="secLab">How are we decorating it?</div>' +
      '<div class="methsel">' +
        '<button data-m="print" class="'+(method==='print'?'on':'')+'">Printed</button>' +
        '<button data-m="emb" class="'+(method==='emb'?'on':'')+'">Embroidered</button>' +
      '</div>' +
      sub + qtyBlock +
      '<div class="declabel">All work is <b>full color, high quality</b>. Not sure yet? Leave it \u2014 we\'ll confirm with you.</div>' +
      '<div class="estp" id="btEst"><div class="estp-note">Calculating\u2026</div></div>';
    b.querySelectorAll('[data-m]').forEach(function(x){ x.addEventListener('click', function(){ method=x.getAttribute('data-m'); stepDeco(); }); });
    b.querySelectorAll('[data-loc]').forEach(function(x){ x.addEventListener('click', function(){ locs=+x.getAttribute('data-loc'); stepDeco(); }); });
    b.querySelectorAll('[data-emb]').forEach(function(x){ x.addEventListener('click', function(){ embType=x.getAttribute('data-emb'); stepDeco(); }); });
    document.getElementById('btDfoot').innerHTML = '<button class="ghost" id="btBack">Back</button><button class="primary" id="btNext">Next: Send</button>';
    document.getElementById('btBack').addEventListener('click', function(){ goStep(1); });
    document.getElementById('btNext').addEventListener('click', function(){ goStep(3); });

    function renderEst(){
    var decoLabel = (method==='emb')
      ? ({text:'Names/Text',logo:'Logo',hard:'Hard-to-handle'}[embType]||'Embroidery')
      : ('Print \u00d7'+locs);
    postPrice(function(d){
      var est = document.getElementById('btEst'); if(!est) return;
      lastEst = d;
      if(!d){ est.innerHTML = '<div class="estp-note">Price will be confirmed on your quote.</div>'; return; }
      if(d.perShirt == null){   // embroidery 84+ → by quote
        est.innerHTML = '<div class="estp-lab">Price per shirt</div><div class="estp-price"><big style="font-size:26px">By quote</big></div>' +
          '<div class="estp-grid"><div class="et"><span>Qty</span><b>'+totalQty()+'</b></div><div class="et"><span>Decoration</span><b>'+decoLabel+'</b></div></div>' +
          '<div class="estp-note">Larger embroidery orders are custom-quoted by our team.</div>';
        return;
      }
      var ps = (+d.perShirt).toFixed(2).split('.');
      est.innerHTML =
        '<div class="estp-lab">Price per shirt</div>' +
        '<div class="estp-price"><sup>$</sup><big>'+ps[0]+'</big><sup>.'+ps[1]+'</sup></div>' +
        '<div class="estp-grid"><div class="et"><span>Qty</span><b>'+totalQty()+'</b></div><div class="et"><span>Decoration</span><b>'+decoLabel+'</b></div></div>' +
        '<div class="estp-calc"><span>'+money(d.perShirt)+' \u00d7 '+totalQty()+(d.discPct?(' \u00b7 '+d.discPct+'% off'):'')+'</span><span class="tot">'+money(d.total)+'</span></div>' +
        '<div class="estp-note">Estimate \u00b7 final quote confirmed by our team</div>';
    });
    }
    var estTimer=null;
    b.querySelectorAll('.qsizes input').forEach(function(i){ i.addEventListener('input', function(){
      updateLineSize(+i.getAttribute('data-i'), i.getAttribute('data-z'), i.value);
      clearTimeout(estTimer); estTimer=setTimeout(renderEst,300);
    }); });
    renderEst();
  }

  function stepSend(){
    var b = document.getElementById('btDbody');
    if (sent){ b.innerHTML = '<div style="padding:30px;text-align:center"><div style="font-size:40px">\u2705</div><h3>Quote request sent!</h3><p style="color:#8a8aa0">Our team will follow up shortly with your final pricing.</p></div>'; document.getElementById('btDfoot').innerHTML=''; return; }
    b.innerHTML =
      '<div class="secLab">Where do we send your quote?</div>' +
      '<div class="field"><label>Name</label><input id="cName" value="'+esc(contact.name)+'" placeholder="Your name"></div>' +
      '<div class="field"><label>Email</label><input id="cEmail" value="'+esc(contact.email)+'" placeholder="you@email.com"></div>' +
      '<div class="field"><label>Phone (optional)</label><input id="cPhone" value="'+esc(contact.phone)+'" placeholder="(630) 555-0100"></div>' +
      '<div class="field"><label>Need it by? / notes</label><textarea rows="3" id="cNotes" placeholder="Art, deadline, anything else\u2026">'+esc(contact.notes)+'</textarea></div>';
    b.querySelector('#cName').addEventListener('input', function(e){ contact.name=e.target.value; });
    b.querySelector('#cEmail').addEventListener('input', function(e){ contact.email=e.target.value; });
    b.querySelector('#cPhone').addEventListener('input', function(e){ contact.phone=e.target.value; });
    b.querySelector('#cNotes').addEventListener('input', function(e){ contact.notes=e.target.value; });
    document.getElementById('btDfoot').innerHTML = '<button class="ghost" id="btBack">Back</button><button class="primary" id="btSend">Send quote request</button>';
    document.getElementById('btBack').addEventListener('click', function(){ goStep(2); });
    document.getElementById('btSend').addEventListener('click', function(){
      if(!contact.name || !contact.email){ alert('Please add your name and email.'); return; }
      sendQuote(this);
    });
  }

  /* ---------- send to the quote desk ----------
   * Until 0.25.0 this button only flipped the drawer to "sent" in the browser.
   * Nothing left the page, so every catalog quote request was lost. It now posts
   * to the same BT Quote endpoint the Quick Quote tool uses (boomerts/v1/quote),
   * so catalog requests land in the same inbox as /quote/ requests. The drawer
   * only shows "sent" once the server confirms the email went out.
   */
  function catalogSummary(d){
    // One labelled line per detail, so color and sizes don't get lost inside
    // a single long garment line in the quote email.
    var lines = quote.map(function(l){
      var sz = lineSizes(l).filter(function(z){ return l.sizes[z]; })
        .map(function(z){ return z + ' x' + l.sizes[z]; }).join(', ');
      return '- ' + [l.brand, l.name].filter(Boolean).join(' ') + ' (Style ' + l.style + ')\n'
        + '   Color: ' + (l.color || 'not chosen') + '\n'
        + '   Sizes: ' + (sz || 'no sizes entered') + ' (' + l.qty + ' pcs)\n'
        + '   Blank: ' + money(l.price) + '/ea';
    }).join('\n');

    // Always name the method. Print used to send only "Locations: 1", so the
    // email never said whether the job was printed or embroidered.
    var deco = (method==='emb')
      ? 'Decoration: EMBROIDERY - ' + ({text:'Names / Text',logo:'Logo',hard:'Hard-to-handle'}[embType] || embType)
      : 'Decoration: PRINT - ' + locs + ' location' + (locs == 1 ? '' : 's') + '\nLocations: ' + locs;

    var price;
    if (!d || d.error || d.code) {
      price = 'Price Per Shirt: to be confirmed\nEst. Total: to be confirmed\n';
    } else if (d.perShirt == null) {
      price = 'Price Per Shirt: By Quote\nEst. Total: By Quote\n';
    } else {
      price = 'Price Per Shirt: ' + money(d.perShirt) + '\nEst. Total: ' + money(d.total)
        + (d.discPct ? ' (' + d.discPct + '% qty discount applied)' : '') + '\n';
    }

    return 'Source: BT Catalog\n'
      + 'Quantity: ' + totalQty() + ' pcs\n'
      + 'Garment:\n' + lines + '\n'
      + deco + '\n'
      + price
      + 'Message: ' + ((contact.notes || '').trim() || '(none)');
  }

  function sendQuote(btn){
    btn.disabled = true;
    btn.textContent = 'Sending\u2026';
    var fail = function(){
      alert('Something went wrong sending your request. Please try again, or call us directly.');
      btn.disabled = false;
      btn.textContent = 'Send quote request';
    };
    // Price it fresh at send time so the email matches what is in the drawer now,
    // even if sizes were changed after the estimate on the Decoration step.
    postPrice(function(d){
      var body = 'your-name=' + encodeURIComponent(contact.name.trim())
        + '&your-email=' + encodeURIComponent(contact.email.trim())
        + '&your-organization='
        + '&your-phone=' + encodeURIComponent((contact.phone || '').trim())
        + '&your-message=' + encodeURIComponent(catalogSummary(d));
      fetch(REST + 'quote', { method:'POST', credentials:'same-origin',
        headers:{'Content-Type':'application/x-www-form-urlencoded'}, body: body })
        .then(function(r){ if (r.ok) { sent = true; stepSend(); } else { fail(); } })
        .catch(fail);
    });
  }

  /* ---------- search ---------- */
  var sT;
  function bindSearch(){
    document.getElementById('btSearch').addEventListener('input', function(e){
      clearTimeout(sT); var v=e.target.value;
      sT = setTimeout(function(){ F.s=v; F.page=1; syncURL(); loadGrid(); loadFacets(); }, 300);
    });
  }

  /* ---------- sort ---------- */
  function bindSort(){
    var sel = document.getElementById('btSort');
    if (!sel) return;
    sel.value = F.sort;
    sel.addEventListener('change', function(){ F.sort = sel.value; F.page = 1; syncURL(); loadGrid(); });
  }

  /* ---------- go ---------- */
  document.getElementById('btGrid').addEventListener('click', function(e){
    var card = e.target.closest('.pcard');
    if (card && card.getAttribute('data-id')) openPDP(card.getAttribute('data-id'));
  });
  bindMenus(); bindSearch(); bindSort();
  var bootPid = readURL();
  var si = document.getElementById('btSearch'); if (si) si.value = F.s;
  renderActive();
  loadFacets();
  loadGrid();
  if (bootPid) openPDP(bootPid, true);   // boot: replace, don't push
})();
