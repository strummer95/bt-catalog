<?php
/*
Plugin Name: BT Catalog
Plugin URI: https://boomerts.com
Description: Boomer T's unified blank-apparel catalog (S&S Activewear + SanMar + EG-PRO) with quote flow. Pulls live product data into a local cache and renders it via the [bt_catalog] shortcode.
Version: 0.21.2
Author: Duck and Rabbit Co.
*/

if (!defined('ABSPATH')) exit;

define('BT_CAT_VERSION', '0.21.2');
define('BT_CAT_DIR', plugin_dir_path(__FILE__));
define('BT_CAT_URL', plugin_dir_url(__FILE__));
define('BT_CAT_FILE', __FILE__);

require_once BT_CAT_DIR . 'includes/db.php';
require_once BT_CAT_DIR . 'includes/tiers.php';
require_once BT_CAT_DIR . 'includes/ingest.php';
require_once BT_CAT_DIR . 'includes/sync.php';
require_once BT_CAT_DIR . 'includes/admin.php';
require_once BT_CAT_DIR . 'includes/ss-admin.php';
require_once BT_CAT_DIR . 'includes/pricing.php';
require_once BT_CAT_DIR . 'includes/sanmar.php';
require_once BT_CAT_DIR . 'includes/egpro.php';
require_once BT_CAT_DIR . 'includes/rest.php';
require_once BT_CAT_DIR . 'includes/export.php';
require_once BT_CAT_DIR . 'includes/shortcode.php';
require_once BT_CAT_DIR . 'includes/updater.php';

// Build the cache table when the plugin is activated.
register_activation_hook(__FILE__, 'bt_cat_install');

// Clean up all scheduled jobs on deactivate.
register_deactivation_hook(__FILE__, function () {
    wp_clear_scheduled_hook(BT_CAT_CRON_HOOK);
    if (defined('BT_CAT_REFRESH_HOOK')) wp_clear_scheduled_hook(BT_CAT_REFRESH_HOOK);
    if (defined('BT_CAT_REFRESH_DAILY_HOOK')) wp_clear_scheduled_hook(BT_CAT_REFRESH_DAILY_HOOK);
});

// Safety net: also make sure the table is current on version bumps.
add_action('init', function () {
    if (get_option('bt_cat_db_version') !== BT_CAT_VERSION) {
        bt_cat_install();
        update_option('bt_cat_db_version', BT_CAT_VERSION);
        // Pricing semantics changed across recent versions (piecePrice as
        // regular cost, per-SKU sale detection, per-color pricing) — queue a
        // full S&S data refresh once per update so cached rows rebuild
        // themselves without any manual re-import.
        // ...but never restart a refresh that's already mid-queue — rapid
        // updates were resetting progress to the front of the line.
        if (function_exists('bt_cat_refresh_start') && function_exists('bt_cat_refresh_pending')
            && bt_cat_refresh_pending() === 0) {
            bt_cat_refresh_start(false);
        }
    }
});
