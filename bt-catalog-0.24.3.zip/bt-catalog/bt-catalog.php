<?php
/*
Plugin Name: BT Catalog
Plugin URI: https://boomerts.com
Description: Boomer T's unified blank-apparel catalog (S&S Activewear + SanMar + EG-PRO) with quote flow. Pulls live product data into a local cache and renders it via the [bt_catalog] shortcode.
Version: 0.24.3
Author: Duck and Rabbit Co.
*/

if (!defined('ABSPATH')) exit;

define('BT_CAT_VERSION', '0.24.3');
define('BT_CAT_DIR', plugin_dir_path(__FILE__));
define('BT_CAT_URL', plugin_dir_url(__FILE__));
define('BT_CAT_FILE', __FILE__);

require_once BT_CAT_DIR . 'includes/db.php';
require_once BT_CAT_DIR . 'includes/tiers.php';
require_once BT_CAT_DIR . 'includes/ingest.php';
require_once BT_CAT_DIR . 'includes/sync.php';
require_once BT_CAT_DIR . 'includes/bt-admin.php';
require_once BT_CAT_DIR . 'includes/admin.php';
require_once BT_CAT_DIR . 'includes/ss-admin.php';
require_once BT_CAT_DIR . 'includes/pricing.php';
require_once BT_CAT_DIR . 'includes/sanmar.php';
require_once BT_CAT_DIR . 'includes/egpro.php';
require_once BT_CAT_DIR . 'includes/rest.php';
require_once BT_CAT_DIR . 'includes/attrs.php';
require_once BT_CAT_DIR . 'includes/colorhex.php';
require_once BT_CAT_DIR . 'includes/export.php';
require_once BT_CAT_DIR . 'includes/shortcode.php';
require_once BT_CAT_DIR . 'includes/updater.php';

// Build the cache table when the plugin is activated.
register_activation_hook(__FILE__, 'bt_cat_install');

// Clean up all scheduled jobs on deactivate.
register_deactivation_hook(__FILE__, function () {
    wp_clear_scheduled_hook(BT_CAT_CRON_HOOK);
    if (defined('BT_CAT_REFRESH_HOOK')) wp_clear_scheduled_hook(BT_CAT_REFRESH_HOOK);
    if (defined('BT_CAT_REFRESH_DAILY_HOOK')) wp_clear_scheduled_hook(BT_CAT_REFRESH_DAILY_HOOK);
});

// Safety net: also make sure the table is current on version bumps.
add_action('init', function () {
    if (get_option('bt_cat_db_version') !== BT_CAT_VERSION) {
        bt_cat_install();
        update_option('bt_cat_db_version', BT_CAT_VERSION);
        // Derived filter attributes (gender/age, neckline, sleeve, closure,
        // sizes, color families) live in columns the STOREFRONT filters on —
        // backfill them right here, on the first request after an update,
        // rather than waiting for an admin page load.
        if (function_exists('bt_cat_attrs_ensure')) bt_cat_attrs_ensure();
        // SanMar sends color NAMES only (no hex, no swatch image), so its colour
        // squares rendered as the grey fallback. Derive a hex from each name on
        // the first request after an update, same as the attrs backfill above.
        if (function_exists('bt_cat_colorhex_ensure')) bt_cat_colorhex_ensure();
        // Pricing semantics changed across recent versions (piecePrice as
        // regular cost, per-SKU sale detection, per-color pricing) — queue a
        // full S&S data refresh once per update so cached rows rebuild
        // themselves without any manual re-import.
        // ...but never restart a refresh that's already mid-queue — rapid
        // updates were resetting progress to the front of the line.
        if (function_exists('bt_cat_refresh_start') && function_exists('bt_cat_refresh_pending')
            && bt_cat_refresh_pending() === 0) {
            bt_cat_refresh_start(false);
        }
    }
});
